## Unit Test

Unit test code is under 'src/test'. You can run unit test use command:   
```bash
./gradlew clean testDebugUnitTest jacocoTestReportDebug
```
This task will run all unit test and produce both unit test report and jacoco test coverage report in 'build/reports'.   
